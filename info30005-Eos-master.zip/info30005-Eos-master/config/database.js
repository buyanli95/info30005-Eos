module.exports = {
  database:'mongodb://eosdev:info30005@ds259119.mlab.com:59119/eosdb'
}
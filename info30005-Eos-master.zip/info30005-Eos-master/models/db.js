// const mongoose = require('mongoose');

// mongoose.connect('mongodb://eosdev:info30005@ds259119.mlab.com:59119/eosdb');
// let db = mongoose.connection;

// db.once('open', function(){
// 	console.log('Connect to MongoDB');
// })

// var userSchema = mongoose.Schema({
// 	fullname: String,
// 	email: String,
// 	password: String
// });
Participant = require("../models/participants");
module.exports.participantedit = function (req, res) {
    //get cname of the post

}

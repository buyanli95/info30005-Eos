// timeCounter = require('../public/js/timeCounter')

module.exports.homePage = function (req, res) {
    //Coming soon page
    //res.render('home_template');
    res.render('eos_home');
};